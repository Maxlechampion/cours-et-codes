<?php
namespace controllers;


class admin 
{
    private $model;
  
    function __construct()
    {
        $this->model=new \models\admin(); 

        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->index();
        }
    }
    public function index(){
       
        $produits = $this->model->GetAllProduits();
       
        $template='views/page/dashboard.phtml';
        include_once 'views/main.phtml';
    }
    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST["pseudo"]) && isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["email"]) && isset($_POST["mdp"]) && isset($_POST["cmdp"])) {
                if (stripslashes(trim($_POST["mdp"])) == stripslashes(trim($_POST["cmdp"]))) {
                    $password = password_hash(stripslashes(trim($_POST["mdp"])), PASSWORD_DEFAULT);
                    // J'appelle la fonction InsertUser() depuis le model afin d'ajouter les données en base
                    $this->model->Insert([stripslashes(trim($_POST["pseudo"])), stripslashes(trim($_POST["nom"])), stripslashes(trim($_POST["prenom"])), stripslashes(trim($_POST["email"])), $password]); 
                     header("location:index.php");

                     exit();
                                    }
                                    else{
                                        echo 'mot de passe non conforme';
                                    }
            }
        }
        // J'appelle la fonction GetAll() depuis le model qui me permet de recuperer tous les utilisateurs en base
       
        // Chargement du formulaire
        $template ='views/page/inscription.phtml';
        include_once 'views/main.phtml';
    }
    public function destroy()
    {
        if (isset($_GET['id'])) {
            // J'appelle DeleteUser() depuis le model, qui me permet de supprimer un utilisateur en fonction de son id 
            $this->model->Delete(intval($_GET['id']));
            header("location: index.php");
            exit();
        } else {
            header("location: index.php");
            exit();
        }
    }

   public function update()
    {
        $this->model->GetById(intval($_GET['id']));
    }

     public function recherche()
    {
        $users = $this->model->Recherches([$_POST['motcle']]);
        $num = 1;
        include_once 'views/formulaire.phtml';
    }

    public function destroy_session()
    {
        session_unset();
     session_destroy();
     header("location:index.php?goto=connexion");
    }

    public function destroy_p()
   {
    if (isset($_GET['id'])) {
      $this->model->Delete(intval($_GET['id']));
      header("location: index.php?goto=produits&target=Delete");
      echo'supprimé avec succès';
      exit();
  } else {
    echo'impossible';
      header("location: index.php?goto=produits");
      exit();
  }
    
}
}
