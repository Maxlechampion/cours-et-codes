<?php
namespace controllers;

class connexion
{
    public function __construct()
    {
        
        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->connecter();
        }
    }

    public function connecter()
    {
        $template = "views/page/connexion.phtml";
        include_once "views/main.phtml";
        
    }

    
}