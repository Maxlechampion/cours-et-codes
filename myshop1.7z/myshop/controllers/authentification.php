<?php
namespace controllers;
class authentification
{
    private $UserModel;
    private $AdminsModel;
    function __construct()
    {
        $this->UserModel=new \models\users();
        $this->AdminsModel=new \models\admin();

        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->login();
        }
    }
    
    public function login()
    {
       
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST["login"]) && isset($_POST["mdp"])) {
                $user = $this->UserModel->GetUserByLogin($_POST["login"]);
                $admin=$this->AdminsModel->GetByAdLogin($_POST["login"]);
                if ($user) {
                    // echo "connexion reussie";
                            if (password_verify($_POST["mdp"],$user['mdp'])){
                        
                        
                        $_SESSION['auth']=json_encode(['user'=>$user['identifiant'],'id'=>$user['id_user']]);
                        header("location: index.php?goto=menu&target=boutique");
                        exit();
                    }
                }elseif($admin){
                    if($admin['mdp']!=NULL){
                        if ($_POST["mdp"]=== $admin['mdp']){
                            $_SESSION['auth']=json_encode(['user'=>$admin['AdLogin'],'id'=>$admin['id_admin'],'role'=>$admin['AdRole']]);
                            header("location: index.php?goto=admin");
                            exit();
                        }
                    }else{
                        header("location: index.php?goto=auth&target=UpdatePassword&id=".$admin['Id']);
                        exit();
                    }
                }
            }
        }
        $template ='views/page/connexion.phtml';
        include_once 'views/main.phtml';
    }
    public function UpdatePassword()
    {
        if(isset($_GET['id'])){

            $admin=$this->AdminsModel->GetById($_GET['id']); 
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (stripslashes(trim($_POST["mdp"])) == stripslashes(trim($_POST["cmdp"]))) {
                $password = password_hash(stripslashes(trim($_POST["mdp"])), PASSWORD_DEFAULT);
                $this->AdminsModel->UpdateAdPasswd([$password,$_POST["user"]]);
                $this->login();
                exit();
            }
        }
        $template ='views/page/PasswordForm.phtml';
        include_once 'views/main.phtml';
    }
}