<?php

namespace apps\router;

class router
{
    public function route()
    {
        spl_autoload_register(function ($class) {
            include_once str_replace('\\', '/', $class) . ".php";
        });

        
        if (isset($_GET['goto'])) {
            switch ($_GET['goto']) {
                // case 'user':
                //     $user = new \controllers\users;
                //     break;
                // case 'contact':
                //     $user = new \controllers\contact;
                //     break;
                case 'authentification':
                    $user = new \controllers\authentification;
                    break;
                case 'admin':
                    $user = new \controllers\admin;
                    break;
                case 'connexion':
                    $user = new \controllers\connexion;
                    break;
                case 'menu' :
                    $user = new \controllers\menu;
                    break;
                case 'inscription' :
                    $user = new \controllers\inscription;
                    break;
                case 'produits' :
                    $user = new \controllers\produits;
                    break;
                
                   
                  
                    
            }
        } else {
            $user = new \controllers\menu;
        }
    }
}
