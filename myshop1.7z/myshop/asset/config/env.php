<?php
$_ENV['userbd']='root';
$_ENV['host']='localhost';
$_ENV['bdd']='myshop';
$_ENV['password']='';