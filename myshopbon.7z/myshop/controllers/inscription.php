<?php
namespace controllers;


class inscription 
{
    private $model;
  
    function __construct()
    {
        $this->model=new \models\users(); 

        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->store();
        }
    }
    public function index(){
       
        $users = $this->model->GetAll();
        $num = 1;
        $template='views/page/liste.phtml';
        include_once 'views/main.phtml';
    }
    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST["pseudo"]) && isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["email"]) && isset($_POST["mdp"]) && isset($_POST["cmdp"])) {
                if (stripslashes(trim($_POST["mdp"])) == stripslashes(trim($_POST["cmdp"]))) {
                    $password = password_hash(stripslashes(trim($_POST["mdp"])), PASSWORD_DEFAULT);
                    // J'appelle la fonction InsertUser() depuis le model afin d'ajouter les données en base
                    $this->model->Insert([stripslashes(trim($_POST["pseudo"])), stripslashes(trim($_POST["nom"])), stripslashes(trim($_POST["prenom"])), stripslashes(trim($_POST["email"])), $password]); 
                     header("location:index.php");

                     exit();
                                    }
                                    else{
                                        echo 'mot de passe non conforme';
                                    }
            }
        }
        // J'appelle la fonction GetAll() depuis le model qui me permet de recuperer tous les utilisateurs en base
       
        // Chargement du formulaire
        $template ='views/page/inscription.phtml';
        include_once 'views/main.phtml';
    }
    public function destroy()
    {
        if (isset($_GET['id'])) {
            // J'appelle DeleteUser() depuis le model, qui me permet de supprimer un utilisateur en fonction de son id 
            $this->model->Delete(intval($_GET['id']));
            header("location: index.php");
            exit();
        } else {
            header("location: index.php");
            exit();
        }
    }

   public function update()
    {
        $this->model->GetById(intval($_GET['id']));
    }

     public function recherche()
    {
        $users = $this->model->Recherches([$_POST['motcle']]);
        $num = 1;
        include_once 'views/formulaire.phtml';
    }

    
}
