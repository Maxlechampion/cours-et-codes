<?php
namespace controllers;


class produits 
{
    private $model;
  
    public function __construct()
    {
        $this->model=new \models\produits(); 

        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->store();
        }
    }
   
       
        
        
  
    public function store()
    {
        
        
          if(isset($_POST["send"])){
              if(!empty($_POST['nom']) && !empty($_POST['detail']) && !empty($_POST['prix'])){
                  define("MAX_SIZE", 3000000);
                  if ( isset($_FILES["img"])) {
                      $fileName = $_FILES["img"]["name"];
                      $fileTmp = $_FILES["img"]["tmp_name"];
                      // printf("tmp folder %s<br>", $fileTmp);
                      $fileSize = $_FILES["img"]["size"];
                      $fileError = $_FILES["img"]["error"];
                    
                      $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                      if (in_array($fileExt, ["png", "jpg", "jpeg"])) {
                        if ($fileError === 0) {
                          if ($fileSize < MAX_SIZE) {
                            $newName = uniqid("IMG-", true) . "." . $fileExt;
                            // printf("newname = %s\n", $newName);
                            $uploadDir =  "./asset/images/upload";
                            move_uploaded_file($fileTmp, "$uploadDir/$newName");
                            $dir = "$uploadDir/$newName";
                            $this->model->Insert([$_POST['nom'],$_POST['detail'],$dir, $_POST['prix']]);
                            echo "ok";
                          } else {
                            echo "Fichier trop volumineux";
                          }
                        } else {
                          echo "Une erreur est survenue lors du chargement du fichier.";
                        }
                      } else {
                        echo "Vous n'êtes pas autorisé à uploader ce type de fichier";
                      }
                      
                    } 

                  }
              }
              $produits = $this->model->GetAll();
              $num=1;
              // echo "<pre>";
              // var_dump($liste_voiture); 
          $template ='views/page/produits.phtml';
          include_once 'views/main.phtml';
    }

      
    public function afficherprod()
    {
      
      $produits = $this->model->GetAll();
      $template = 'views/page/boutique.phtml';
      include_once 'views/main.phtml';
    }
   

    
    public function destroy()
    {
        if (isset($_GET['id'])) {
            // J'appelle DeleteUser() depuis le model, qui me permet de supprimer un utilisateur en fonction de son id 
            $this->model->Delete(intval($_GET['id']));
            // header("location: index.php?goto=produits&target=destroy");

            exit();
        } else {
            // header("location: index.php?goto=dasboard");
            exit();

        }
        $produits = $this->model->GetAll();
        $template = 'views/page/da.phtml';
        include_once 'views/main.phtml';
    }

   public function update()
    {
        // $this->model->GetById(intval($_GET['id']));
        $produits = $this->model->Update(array ($_POST['nom'], $_POST['detail'], 
        $_POST['prix'], $_POST['id']));
        $template = 'views/page/dashboard.phtml';
        include_once 'views/main.phtml';
    }

     public function recherche()
    {
        $users = $this->model->Recherches([$_POST['motcle']]);
        $num = 1;
        include_once 'views/formulaire.phtml';
    }

    public function destroy_session()
    {
        session_unset();
     session_destroy();
     header("location:index.php?goto=connexion"); 
    }
  }
 

   
