<?php
namespace controllers;

class contact
{
    public function __construct()
    {
        
        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->afficherCont();
        }
    }

    public function affichercont()
    {
        $template = "views/page/contact.phtml";
        include_once "views/main.phtml";
        
    }

}