<?php
namespace controllers;

class menu
{
    public function __construct()
    {
        
        if(isset($_GET['target'])){
            $target=$_GET['target'];
            $this->$target(); 
        }else{
            $this->accueil();
        }
    }

    public function accueil()
    {
        $template = "views/page/accueil.phtml";
        include_once "views/main.phtml";
        
    }

    public function contact()
    {
        $template = "views/page/contact.phtml";
        include_once "views/main.phtml";
        
    }
    public function boutique()
    {
        $template = "views/page/boutique.phtml";
        include_once "views/main.phtml";
        
    }


}