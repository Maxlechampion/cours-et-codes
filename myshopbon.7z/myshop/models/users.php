<?php
namespace models;


class users extends database {
public function Insert(array $data){
    $this->SendData("INSERT INTO users(pseudo,nom, prenom, email, mdp) VALUES (?,?,?,?,?)",$data);
}
public function Update(array $data){
    $this->SendData("UPDATE users SET nom=?, prenom=?,email=?,mdp=? WHERE id_user=?",$data);
}
public function Delete(int $id){
    $this->SendData("DELETE FROM users WHERE id_user=?",[$id]);
}
public function GetAll(): array{
    return $this->GetManyData("SELECT id_user,nom, prenom,email FROM users",NULL);
}
public function GetById(int $id){
    return $this->GetOneData("SELECT id_user,nom, prenom,email FROM users WHERE id_user=?",[$id]);
}
public function Recherches(array $data){
   return $this->GetManyData("SELECT id_user,nom, prenom,email FROM users WHERE nom=? or prenom=? or email=?" , $data);
}
public function GetUserByLogin(string $login){
    return $this->GetOneData("SELECT id_user,pseudo,nom, prenom,email, mdp FROM users WHERE pseudo=?",[$login]);
}
}