<?php 
namespace models;
class admin extends database
{
    public function Insert(array $data)
    {
        $this->SendData("INSERT INTO admins (nom, prenom, AdLogin, mdp) VALUES (?,?,?,?)",$data);
    }
    public function Update(array $data)
    {
        $this->SendData("UPDATE admins SET nom=?, AdLogin=?, mdp=? WHERE id_admin=?",$data);
    }
    public function Delete(int $id)
    {
        $this->SendData("DELETE FROM admins WHERE id=?",[$id]);
    }
    public function GetAll()
    {
        return $this->GetManyData("SELECT id_admin, nom,  AdLogin, mdp FROM admins");
    }
    public function GetById(int $id)
    {
        return $this->GetOneData("SELECT id_admin, nom,  AdLogin, mdp FROM admins WHERE id_admin=?",[$id]);
    }
    public function GetByAdLogin(string $login)
    {
        return $this->GetOneData("SELECT id_admin, nom, prenom, AdLogin, mdp FROM admins WHERE AdLogin=?",[$login]);
    }
    public function UpdateAdprenom(array $data)
    {
        $this->SendData("UPDATE admins SET mdp=? WHERE id_admin=?",$data);
    }
}