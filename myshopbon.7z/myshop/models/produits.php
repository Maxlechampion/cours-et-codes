<?php 
namespace models;
class produits extends database
{
    public function Insert(array $data)
    {
        $this->SendData("INSERT INTO produits (nom, detail, image_p, prix) VALUES (?,?,?,?)",$data);
    }
    public function Update(array $data)
    {
        $this->SendData("UPDATE produits SET nom=?, detail=?, prix=? WHERE id=?",$data);
    }
    public function Delete(int $id)
    {
        $this->SendData("DELETE FROM produits WHERE id=?",[$id]);
    }
    public function GetAll():array
    {
        return $this->GetManyData("SELECT id, nom, detail, image_p, prix FROM produits");
    }
    public function GetById(int $id)
    {
        return $this->GetOneData("SELECT id_admin, nom,  AdLogin, mdp FROM admins WHERE id_admin=?",[$id]);
    }
    public function GetByAdLogin(string $login)
    {
        return $this->GetOneData("SELECT id_admin, nom, prenom, AdLogin, mdp FROM admins WHERE AdLogin=?",[$login]);
    }
    public function UpdateAdprenom(array $data)
    {
        $this->SendData("UPDATE admins SET mdp=? WHERE id=?",$data);
    }
}