# JavaScript-Transparent-Form
😍Pretty🥰 and Ergonomic😀 login and connection form made with JavaScript.

With two functionnalities For login and For connecting

👉 Join me on my YouTube channel here https://www.youtube.com/c/CodingCity
